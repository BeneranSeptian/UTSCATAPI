package seftian.uts

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import seftian.uts.databinding.ItemCatBinding

class CatViewHolder(itemView : View, private val context : Context): RecyclerView.ViewHolder(itemView) {
    private val binding = ItemCatBinding.bind(itemView)

    fun bindView(catDetail: CatDetail,clickListener:(CatDetail)->Unit){
//        Glide.with(context)
//            .load(catDetail.image.url)
//            .into(binding.ivCat)
        binding.tvCatBreed.text = catDetail.name.toString()
//        binding.tvCatCharacter.text = catDetail.temperament
        itemView.setOnClickListener{
        clickListener(catDetail)
}
    }



//    fun imageView(catImage: CatImage){
//        Glide.with(context)
//           .load(catImage.url)
//            .into(binding.ivCat)
//    }






}