package seftian.uts

import android.graphics.drawable.ClipDrawable.HORIZONTAL
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout.HORIZONTAL
import android.widget.Spinner
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.HORIZONTAL
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import seftian.uts.databinding.ActivityMainBinding

class MainActivity :AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var catDetail: CatDetail
    private val list = ArrayList<CatDetail>()
    private val listImage = ArrayList<CatImage>()
    private var breeds:List<CatDetail> = ArrayList(list)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.rvKucing.setHasFixedSize(true)
        binding.rvKucing.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false )
        binding.rvKucingMid.setHasFixedSize(true)
        binding.rvKucingMid.layoutManager = LinearLayoutManager(this)
        showCat()
        showImage()

       /* binding.btnSearch.setOnClickListener(){
            var search = binding.etSearch.text.toString()
            Toast.makeText(this,search, Toast.LENGTH_SHORT).show()


        }
*/
    }

    fun showCat (){
        CatClient.instance.getPost().enqueue(object : Callback<ArrayList<CatDetail>> {
            override fun onResponse(
                call: Call<ArrayList<CatDetail>>,
                response: Response<ArrayList<CatDetail>>
            ) {

                response.body()?.let { list.addAll(it) }
                val adapter = CatAdapter(list,:: catClicked)
                binding.rvKucing.adapter=adapter

            }
            override fun onFailure(call: Call<ArrayList<CatDetail>>, t: Throwable) {
            }

        })


  }

    private fun catClicked(catDetail:CatDetail){
        Toast.makeText(this, catDetail.reference_image_id, Toast.LENGTH_SHORT).show()
//        val bundle = bundleOf("title" to movieDetail.title)
//        findNavController().navigate(R.id.action_to_movie_detail, bundle)
    }

    fun showImage (){
        CatClient.instance.getPost().enqueue(object : Callback<ArrayList<CatDetail>> {
            override fun onResponse(
                call: Call<ArrayList<CatDetail>>,
                response: Response<ArrayList<CatDetail>>
            ) {

                response.body()?.let { list.addAll(it) }
                val adapter = DetailAdapter(list,:: catClicked)
                binding.rvKucingMid.adapter=adapter

            }
            override fun onFailure(call: Call<ArrayList<CatDetail>>, t: Throwable) {
            }

        })


    }





}



